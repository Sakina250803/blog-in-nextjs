import "./globals.css";
import Navbar from "../components/Navbar";

export const metadata = {
  title: "Flower Blog",
  description: "A peaceful flower blog",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <Navbar />
        <main className="container">{children}</main>
        <footer className="footer">
          2026 Flower Blog bunni 
        </footer>
      </body>
    </html>
  );
}
