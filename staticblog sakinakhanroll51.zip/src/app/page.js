import posts from "../data/posts";
import BlogCard from "../components/BlogCard";

export default function HomePage() {
  return (
    <>
      <h1>Welcome to Flower Blog </h1>
      <p style={{ margin: "15px 0 35px" }}>
        A calm static blog about beautiful flowers.
      </p>

      <div className="grid">
        {posts.map((post) => (
          <BlogCard key={post.slug} post={post} />
        ))}
      </div>
    </>
  );
}
