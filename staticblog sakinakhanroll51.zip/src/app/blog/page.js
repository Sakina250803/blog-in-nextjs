import posts from "../../data/posts";
import BlogCard from "../../components/BlogCard";

export default function BlogPage() {
  return (
    <>
      <h1>All Blog Posts</h1>
      <div className="grid" style={{ marginTop: "30px" }}>
        {posts.map(post => (
          <BlogCard key={post.slug} post={post} />
        ))}
      </div>
    </>
  );
}
