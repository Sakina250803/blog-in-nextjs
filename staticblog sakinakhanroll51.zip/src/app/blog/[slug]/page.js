import posts from "../../../data/posts";

export async function generateStaticParams() {
  return posts.map(post => ({
    slug: post.slug
  }));
}

export default async function BlogDetail({ params }) {
  const { slug } = await params; // unwrap promise
  const post = posts.find(p => p.slug === slug);

  if (!post) return <h2 style={{ color: "#000", textAlign: "center", marginTop: "50px" }}>Post not found</h2>;

  return (
    <article
      style={{
        maxWidth: "800px",
        margin: "40px auto",
        padding: "20px",
        backgroundColor: "#fff", // white background
        borderRadius: "12px",
        boxShadow: "0 4px 15px rgba(0,0,0,0.1)",
        color: "#000", // black text
        lineHeight: "1.7",
        fontFamily: "sans-serif",
      }}
    >
      {/* Title */}
      <h1 style={{ color: "#000", marginBottom: "20px", fontSize: "2.2rem" }}>
        {post.title}
      </h1>

      {/* Image */}
      <div style={{ marginBottom: "20px", textAlign: "center" }}>
        <img
          src={post.image}
          alt={post.title}
          style={{
            maxWidth: "100%",
            height: "auto",
            borderRadius: "12px",
            objectFit: "cover",
            transition: "transform 0.3s",
          }}
        />
      </div>

      {/* Content */}
      <div style={{ whiteSpace: "pre-line", fontSize: "1.1rem" }}>
        {post.content}
      </div>

      {/* Back link */}
      <p style={{ marginTop: "30px" }}>
        <a href="/blog" style={{ color: "#0070f3", textDecoration: "underline" }}>
          ← Back to Blog
        </a>
      </p>
    </article>
  );
}
