"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

export default function Home() {
  const [posts, setPosts] = useState([]);

  // Load posts from localStorage
  useEffect(() => {
    const storedPosts = JSON.parse(localStorage.getItem("posts")) || [];
    setPosts(storedPosts);
  }, []);

  const handleDelete = (slug) => {
    const updatedPosts = posts.filter((p) => p.slug !== slug);
    setPosts(updatedPosts);
    localStorage.setItem("posts", JSON.stringify(updatedPosts));
  };

  return (
    <div>
      <Link href="/blog/create">
        <button style={{ marginBottom: "20px" }}>➕ Create Post</button>
      </Link>

      {posts.length === 0 && <p>No posts yet.</p>}

      <div style={grid}>
        {posts.map((post) => (
          <div key={post.slug} style={card}>
            {post.image && (
              <img src={post.image} alt={post.title} style={img} />
            )}

            <h3>{post.title}</h3>
            <p>{post.content.slice(0, 100)}...</p>

            <div style={actions}>
              <Link href={`/blog/${post.slug}`}>
                <button>View</button>
              </Link>

              <Link href={`/blog/edit/${post.slug}`}>
                <button>Edit</button>
              </Link>

              <button onClick={() => handleDelete(post.slug)}>Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

const grid = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
  gap: "20px"
};

const card = {
  background: "#1b263b",
  padding: "15px",
  borderRadius: "12px",
  boxShadow: "0 8px 25px rgba(0,0,0,0.6)",
  transition: "0.3s"
};

const img = {
  width: "100%",
  height: "180px",
  objectFit: "cover",
  borderRadius: "10px",
  marginBottom: "10px"
};

const actions = {
  display: "flex",
  gap: "10px",
  marginTop: "10px"
};
