
import "./globals.css";
export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <title>Flower Blog</title>
        <style>{`
          * { margin:0; padding:0; box-sizing:border-box; }
          body {
            font-family: 'Segoe UI', sans-serif;
            background:#0d1b2a; 
            color:#fff; 
            transition: background 0.3s, color 0.3s;
          }
          header {
            background: linear-gradient(90deg, #1b263b, #415a77);
            color: #fff;
            padding: 20px 0;
            text-align: center;
            box-shadow: 0 4px 10px rgba(0,0,0,0.5);
          }
          header h1 { font-size:2rem; letter-spacing:1px; }
          footer { background:#1b263b; color:#fff; text-align:center; padding:15px; margin-top:40px; font-size:0.9rem; }
          a { color:#00bfff; text-decoration:none; transition: 0.3s; }
          a:hover { text-decoration:underline; }
          button {
            padding:10px 16px; 
            background:#415a77; 
            color:#fff; 
            border:none; 
            border-radius:8px; 
            cursor:pointer; 
            transition: all 0.3s;
          }
          button:hover { background:#00bfff; transform:translateY(-2px);}
          input, textarea {
            width:100%; padding:12px; margin-bottom:15px; border:1px solid #33415c; border-radius:8px;
            font-size:1rem; background:#0d1b2a; color:#fff;
          }
          h2 { margin-bottom:15px; color:#00bfff; }
          h3 { color:#fff; font-size:1.3rem; margin-bottom:5px; }
          img { max-width:100%; border-radius:12px; margin:15px 0; transition: transform 0.3s; }
          img:hover { transform: scale(1.05); }
          .container { max-width: 1000px; margin: 20px auto; padding:20px; }
          .card { border-radius:12px; overflow:hidden; box-shadow:0 6px 20px rgba(0,0,0,0.6); background:#1b263b; transition: transform 0.3s, box-shadow 0.3s; }
          .card:hover { transform: translateY(-5px); box-shadow:0 10px 25px rgba(0,0,0,0.8);}
          @media (max-width:768px) {
            header h1 { font-size:1.5rem; }
            button { font-size:0.9rem; padding:8px 12px; }
          }
        `}</style>
      </head>
      <body>
        <header><h1>Flower Blog </h1></header>
        <div className="container">{children}</div>
        <footer> 2026 Flower Blog</footer>
      </body>
    </html>
  );
}
