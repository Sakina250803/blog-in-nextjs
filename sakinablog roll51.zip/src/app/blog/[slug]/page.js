"use client";

import { useParams, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import Link from "next/link";

export default function ViewPost() {
  const { slug } = useParams();
  const router = useRouter();

  const [post, setPost] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const storedPosts = JSON.parse(localStorage.getItem("posts")) || [];
    const foundPost = storedPosts.find((p) => p.slug === slug);

    if (!foundPost) {
      alert("Post not found");
      router.push("/");
      return;
    }

    setPost(foundPost);
    setLoading(false);
  }, [slug, router]);

  if (loading) return <p>Loading...</p>;

  return (
    <div style={styles.card}>
      <Link href="/">
        <button style={styles.back}>← Back</button>
      </Link>

      <h1 style={styles.title}>{post.title}</h1>

      {post.image && (
        <img
          src={post.image}
          alt={post.title}
          style={styles.image}
        />
      )}

      <p style={styles.content}>{post.content}</p>
    </div>
  );
}

const styles = {
  card: {
    maxWidth: "800px",
    margin: "40px auto",
    background: "#1b263b",
    padding: "30px",
    borderRadius: "16px",
    boxShadow: "0 10px 35px rgba(0,0,0,0.7)",
    animation: "fadeIn 0.4s ease-in-out"
  },
  back: {
    marginBottom: "15px",
    background: "#415a77"
  },
  title: {
    color: "#00b4d8",
    marginBottom: "15px"
  },
  image: {
    width: "100%",
    maxHeight: "350px",
    objectFit: "cover",
    borderRadius: "14px",
    margin: "20px 0"
  },
  content: {
    fontSize: "1.05rem",
    lineHeight: "1.7",
    color: "#e0e1dd"
  }
};
