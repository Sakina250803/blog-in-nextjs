"use client";

import { useParams, useRouter } from "next/navigation";
import { useEffect, useState } from "react";

export default function EditPost() {
  const { slug } = useParams();
  const router = useRouter();

  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [image, setImage] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const storedPosts = JSON.parse(localStorage.getItem("posts")) || [];
    const post = storedPosts.find((p) => p.slug === slug);

    if (!post) {
      alert("Post not found");
      router.push("/");
      return;
    }

    setTitle(post.title);
    setContent(post.content);
    setImage(post.image || "");
    setLoading(false);
  }, [slug, router]);

  const handleUpdate = (e) => {
    e.preventDefault();

    const storedPosts = JSON.parse(localStorage.getItem("posts")) || [];

    const updatedPosts = storedPosts.map((p) =>
      p.slug === slug
        ? { ...p, title, content, image }
        : p
    );

    localStorage.setItem("posts", JSON.stringify(updatedPosts));
    router.push("/");
  };

  if (loading) return <p>Loading...</p>;

  return (
    <div style={styles.wrapper}>
      <h2 style={styles.heading}>Edit Post</h2>

      <form onSubmit={handleUpdate} style={styles.form}>
        <input
          style={styles.input}
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Post title"
          required
        />

        <input
          style={styles.input}
          value={image}
          onChange={(e) => setImage(e.target.value)}
          placeholder="Image URL (/images/flower.jpg)"
        />

        <textarea
          style={styles.textarea}
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Post content"
          required
        />

        <button style={styles.button}>Update Post</button>
      </form>
    </div>
  );
}

const styles = {
  wrapper: {
    maxWidth: "600px",
    margin: "40px auto",
    background: "#1b263b",
    padding: "30px",
    borderRadius: "14px",
    boxShadow: "0 10px 30px rgba(0,0,0,0.6)",
    animation: "fadeIn 0.4s ease-in-out"
  },
  heading: {
    textAlign: "center",
    marginBottom: "20px",
    color: "#00b4d8"
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "15px"
  },
  input: {
    padding: "12px",
    borderRadius: "8px",
    border: "1px solid #415a77",
    background: "#0d1b2a",
    color: "#fff"
  },
  textarea: {
    padding: "12px",
    minHeight: "140px",
    borderRadius: "8px",
    border: "1px solid #415a77",
    background: "#0d1b2a",
    color: "#fff"
  },
  button: {
    padding: "12px",
    background: "linear-gradient(90deg, #4361ee, #4cc9f0)",
    color: "#fff",
    border: "none",
    borderRadius: "10px",
    cursor: "pointer",
    fontWeight: "bold",
    transition: "0.3s"
  }
};
