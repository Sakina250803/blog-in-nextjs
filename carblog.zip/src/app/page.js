import posts from "../data/posts";
import BlogCard from "../components/BlogCard";

export default function HomePage() {
  return (
    <>
      <h1>Welcome to car Blog </h1>
      <p style={{ margin: "15px 0 35px" }}>
       my car blog is a vibrant online platform dedicated to all things automotive. We share the latest news, in-depth reviews, and insightful articles about cars, catering to enthusiasts and casual readers alike. Whether you're passionate about classic cars, interested in the latest electric vehicles, or looking for maintenance tips, our blog offers a wealth of information to fuel your automotive interests. Join us on this exciting journey through the world of cars!
      </p>

      <div className="grid">
        {posts.map((post) => (
          <BlogCard key={post.slug} post={post} />
        ))}
      </div>
    </>
  );
}
