import "./globals.css";
import Navbar from "../components/Navbar";

export const metadata = {
  title: "car Blog",
  description: "A  authentic car blog",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <Navbar />
        <main className="container">{children}</main>
        <footer className="footer">
          2026 car Blog 
        </footer>
      </body>
    </html>
  );
}
