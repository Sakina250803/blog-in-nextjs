import Link from "next/link";

export default function BlogCard({ post }) {
  return (
    <Link href={`/blog/${post.slug}`}>
      <div className="card">
        <img src={post.image} alt={post.title} />
        <div className="card-content">
          <h3>{post.title}</h3>
          <p>{post.excerpt}</p>
        </div>
      </div>
    </Link>
  );
}
